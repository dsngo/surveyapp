import { combineReducers } from "redux";
import { SET_SEARCH_TERM, ADD_API_DATA } from "./actions";

const searchTerm = (state = "", action: any) => (action.type === SET_SEARCH_TERM ? action.searchTerm : state);

const apiData = (state = {}, action: any) =>
    action.type === ADD_API_DATA ? { [action.apiData.id]: action.apiData } : state;

export const rootReducer = combineReducers({ searchTerm, apiData });
