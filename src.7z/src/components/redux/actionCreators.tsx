// import axios from "axios";
import { SET_SEARCH_TERM, ADD_API_DATA } from "./actions";

export const setSearchTerm = (searchTerm: string) => ({
    searchTerm,
    type: SET_SEARCH_TERM,
});
