export const SET_SEARCH_TERM = "SET_SEARCH_TERM";
export const ADD_API_DATA = "ADD_API_DATA";
