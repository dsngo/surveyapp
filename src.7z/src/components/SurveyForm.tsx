import * as React from "react";
import { connect } from "react-redux";
import Scrollbars from "react-custom-scrollbars";
import Settings from "./Settings";

const SurveyForm: React.SFC = props => (
    <Scrollbars id="scroll-survey-form" style={{ height: "calc(100vh - 65px)", width: "100vw"}} autoHide>
        <div className="row">
            <div className="container survey-form" style={{ paddingTop: "15px" }}>
                 <Settings />
                <div className="form-create clear-fix">
                    <div className="tabs clear-fix">
                        <div className="questions-tab active-tab">QUESTIONS</div>
                        <div className="responses-tab">RESPONSES</div>
                    </div>
                    
                    <div className="form-content">
                        <div className="form-info">
                            <div className="form-title">
                                <div className="group">
                                    <input type="text" required />
                                    <span className="highlight" />
                                    <span className="bar" />
                                    <label>Title</label>
                                </div>
                            </div>
                            <div className="form-description">
                                <div className="group">
                                    <input type="text" required />
                                    <span className="highlight" />
                                    <span className="bar" />
                                    <label>Description</label>
                                </div>
                                
                            </div>
                        </div>
                        <div className="form-question">
                            <div className="group">
                                <input type="text" required />
                                <span className="highlight" />
                                <span className="bar" />
                                <label>Question 1</label>
                                
                            </div>
                            <div className="input-field select-materialize">
                                <select>
                                    <option value="" disabled selected>Choose answer type</option>
                                    <option value="1">Short Answer</option>
                                    <option value="2">Long Answer</option>
                                    <option value="3">Checkbox</option>
                                </select>
                                <label>Answer type</label>
                            </div>
                        </div>
                        <div className="form-question">
                            <div className="group">
                                <input type="text" required />
                                <span className="highlight" />
                                <span className="bar" />
                                <label>Question 2</label>
                            </div>
                            <div className="input-field select-materialize">
                                <select>
                                    <option value="" disabled selected>Choose answer type</option>
                                    <option value="1">Short Answer</option>
                                    <option value="2">Long Answer</option>
                                    <option value="3">Checkbox</option>
                                </select>
                                <label>Answer type</label>
                            </div>
                        </div>
                        <div className="form-question">
                            <div className="group">
                                <input type="text" required />
                                <span className="highlight" />
                                <span className="bar" />
                                <label>Question 3</label>
                            </div>
                            <div className="input-field select-materialize">
                                <select>
                                    <option value="" disabled selected>Choose answer type</option>
                                    <option value="1">Short Answer</option>
                                    <option value="2">Long Answer</option>
                                    <option value="3">Checkbox</option>
                                </select>
                                <label>Answer type</label>
                            </div>
                        </div>
                        <div className="form-question">
                            <div className="group">
                                <input type="text" required />
                                <span className="highlight" />
                                <span className="bar" />
                                <label>Question 4</label>
                            </div>
                            <div className="input-field select-materialize">
                                <select>
                                    <option value="" disabled selected>Choose answer type</option>
                                    <option value="1">Short Answer</option>
                                    <option value="2">Long Answer</option>
                                    <option value="3">Checkbox</option>
                                </select>
                                <label>Answer type</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </Scrollbars>
);

export default connect()(SurveyForm);
