import * as React from "react";
import { connect } from "react-redux";

const Settings: React.SFC = props => (
    <div className="menu-settings">
        <div>
            <div className="settings-icon add-question">
                <i className="fa fa-plus-circle" />
            </div>
        </div>
        <div>
            <div className="settings-icon add-text">
                <i className="fa fa-font" aria-hidden="true" />
            </div>
        </div>
        <div>
            <div className="settings-icon">
                <i className="fa fa-picture-o" aria-hidden="true" />
            </div>
        </div>
        <div>
            <div className="settings-icon">
                <i className="fa fa-youtube-play" aria-hidden="true" />
            </div>
        </div>
        <div>
            <div className="settings-icon">
                <i className="fa fa-bars" aria-hidden="true" />
            </div>
        </div>
    </div>
);

export default connect()(Settings);
