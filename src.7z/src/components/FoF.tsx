import * as React from "react";

const FoF = () => <h1 style={{ textAlign: "center" }}>404! :D:D</h1>;

export default FoF;
